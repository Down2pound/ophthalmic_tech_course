import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Curriculum from "./pages/Curriculum";
import Learn from "./pages/Learn";
import Checkout from "./pages/Checkout";
import Policies from "./pages/Policies";
import SkillsPassport from "./pages/SkillsPassport";
import CareerToolkit from "./pages/CareerToolkit";
import OnboardingAssessment from "./pages/OnboardingAssessment";
import PracticePacks from "./pages/PracticePacks";
import PracticeSeatAdmin from "./pages/PracticeSeatAdmin";
import CertificatePreview from "./pages/CertificatePreview";
import LaunchReadiness from "./pages/LaunchReadiness";
import AdminAlertTemplates from "./pages/AdminAlertTemplates";
import SendAlerts from "./pages/SendAlerts";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/curriculum"} component={Curriculum} />
      <Route path={"/learn"} component={Learn} />
      <Route path={"/checkout"} component={Checkout} />
      <Route path={"/policies"} component={Policies} />
      <Route path={"/skills-passport"} component={SkillsPassport} />
      <Route path={"/career-toolkit"} component={CareerToolkit} />
      <Route path={"/onboarding"} component={OnboardingAssessment} />
      <Route path={"/practice-packs"} component={PracticePacks} />
      <Route path={"/practice-seat-admin"} component={PracticeSeatAdmin} />
      <Route path={"/certificate-preview"} component={CertificatePreview} />
      <Route path={"/launch-readiness"} component={LaunchReadiness} />
      <Route path={"/send"} component={SendAlerts} />
      <Route path={"/admin"} component={AdminAlertTemplates} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
