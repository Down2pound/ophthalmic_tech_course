import { describe, expect, it } from "vitest";
import {
  commerceSchemaSql,
  commerceSchemaTables,
  getCommerceSchemaChecklist,
} from "./commerceSchema";

describe("commerceSchemaSql", () => {
  it("defines durable purchase and enrollment tables", () => {
    expect(commerceSchemaTables).toEqual([
      "commerce_purchases",
      "commerce_enrollments",
      "commerce_practice_seat_packs",
      "commerce_practice_seat_assignments",
      "commerce_practice_inquiries",
      "commerce_learner_interests",
    ]);
    expect(commerceSchemaSql).toContain(
      "CREATE TABLE IF NOT EXISTS commerce_purchases"
    );
    expect(commerceSchemaSql).toContain(
      "CREATE TABLE IF NOT EXISTS commerce_enrollments"
    );
    expect(commerceSchemaSql).toContain(
      "CREATE TABLE IF NOT EXISTS commerce_practice_seat_packs"
    );
    expect(commerceSchemaSql).toContain(
      "CREATE TABLE IF NOT EXISTS commerce_practice_seat_assignments"
    );
    expect(commerceSchemaSql).toContain(
      "CREATE TABLE IF NOT EXISTS commerce_practice_inquiries"
    );
    expect(commerceSchemaSql).toContain(
      "CREATE TABLE IF NOT EXISTS commerce_learner_interests"
    );
  });

  it("protects Stripe fulfillment from duplicate events and sessions", () => {
    expect(commerceSchemaSql).toContain("stripe_event_id TEXT NOT NULL UNIQUE");
    expect(commerceSchemaSql).toContain(
      "checkout_session_id TEXT NOT NULL UNIQUE"
    );
    expect(commerceSchemaSql).toContain(
      "purchase_id TEXT NOT NULL REFERENCES commerce_purchases"
    );
  });

  it("tracks practice seat pack capacity safely", () => {
    expect(commerceSchemaSql).toContain("seat_count INTEGER");
    expect(commerceSchemaSql).toContain("total_seats INTEGER NOT NULL");
    expect(commerceSchemaSql).toContain(
      "assigned_seats INTEGER NOT NULL DEFAULT 0"
    );
    expect(commerceSchemaSql).toContain(
      "CHECK (assigned_seats <= total_seats)"
    );
    expect(commerceSchemaSql).toContain("UNIQUE (seat_pack_id, learner_email)");
    expect(commerceSchemaSql).toContain(
      "commerce_enrollments_source_learner_idx"
    );
  });

  it("stores custom practice inquiry leads durably", () => {
    expect(commerceSchemaSql).toContain("practice_name TEXT NOT NULL");
    expect(commerceSchemaSql).toContain("contact_email TEXT NOT NULL");
    expect(commerceSchemaSql).toContain("estimated_learner_count INTEGER");
    expect(commerceSchemaSql).toContain(
      "commerce_practice_inquiries_contact_email_idx"
    );
  });

  it("stores individual learner interest leads durably", () => {
    expect(commerceSchemaSql).toContain("learner_name TEXT NOT NULL");
    expect(commerceSchemaSql).toContain("background TEXT NOT NULL");
    expect(commerceSchemaSql).toContain("goal TEXT NOT NULL");
    expect(commerceSchemaSql).toContain("commerce_learner_interests_email_idx");
  });
});

describe("getCommerceSchemaChecklist", () => {
  it("summarizes the production database gates still required", () => {
    expect(getCommerceSchemaChecklist()).toEqual([
      "Run pnpm db:setup against managed PostgreSQL.",
      "Configure DATABASE_URL so commerce records use PostgreSQL repositories.",
      "Wrap purchase recording and enrollment provisioning in one transaction.",
      "Keep Stripe webhook idempotency enforced by unique event and checkout session fields.",
      "Provision practice seat packs from checkout metadata before inviting individual learners.",
      "Assign practice seats to learner emails without exceeding purchased seat capacity.",
      "Store practice inquiries durably so larger team leads do not depend on mailto links.",
      "Store learner interest leads durably so individual buyers can be contacted before paid enrollment opens.",
    ]);
  });
});
