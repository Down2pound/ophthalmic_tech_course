import { describe, expect, it } from "vitest";
import { renderManualQaTemplate } from "./manualQaTemplate";

describe("renderManualQaTemplate", () => {
  it("renders a safe manual launch QA evidence template", () => {
    const template = renderManualQaTemplate({
      generatedAt: "2026-07-13T12:00:00.000Z",
    });

    expect(template).toContain("OptiTech Academy Manual Launch QA Evidence");
    expect(template).toContain("Test Stripe checkout and webhook fulfillment");
    expect(template).toContain("Test the paid learner flow end to end");
    expect(template).toContain("Run browser and accessibility QA");
    expect(template).toContain("Paid Launch Evidence Details");
    expect(template).toContain("Stripe checkout session ID:");
    expect(template).toContain("Webhook delivery status:");
    expect(template).toContain("Individual checkout success return URL:");
    expect(template).toContain(
      "Individual success return showed the learner payment received message"
    );
    expect(template).toContain(
      "Individual checkout required policy acceptance"
    );
    expect(template).toContain("Passwordless Email Delivery");
    expect(template).toContain(
      "Sign-in email arrived without exposing raw token"
    );
    expect(template).toContain(
      "Learner could request a fresh sign-in link from the Learn page access panel"
    );
    expect(template).toContain("returned 429 with Retry-After");
    expect(template).toContain("Practice checkout success return URL:");
    expect(template).toContain(
      "Practice success return showed practice pack payment received next steps"
    );
    expect(template).toContain("Practice checkout required policy acceptance");
    expect(template).toContain("Custom Practice Inquiry Test");
    expect(template).toContain("Larger-practice inquiry path is visible");
    expect(template).toContain("Sitemap URL or generated sitemap path:");
    expect(template).toContain("ENABLE_PAID_ENROLLMENT stayed false");
    expect(template).toContain("Do not paste card numbers");
    expect(template).toContain("Deployment URL:");
    expect(template).toContain("Commit SHA:");
    expect(template).not.toContain("sk_test_");
    expect(template).not.toContain("whsec_");
  });
});
