import { mkdir, readFile, rm, writeFile } from "node:fs/promises";
import path from "node:path";
import { renderLaunchDoctorReport } from "./launchDoctor";
import type { RuntimeLaunchReadinessReport } from "../config/runtimeReadiness";
import { getRuntimeLaunchReadinessReport } from "../config/runtimeReadiness";

export interface LaunchEvidenceBundleInput {
  outputDir: string;
  projectRoot?: string;
  generatedAt?: string;
  readinessReport?: RuntimeLaunchReadinessReport;
}

export interface LaunchEvidenceBundleResult {
  outputDir: string;
  files: string[];
}

function renderReadme({
  generatedAt,
  readinessReport,
}: {
  generatedAt: string;
  readinessReport: RuntimeLaunchReadinessReport;
}): string {
  return [
    "# OptiTech Academy Launch Evidence Bundle",
    "",
    `Generated at: ${generatedAt}`,
    "",
    "This folder is safe to save to Google Drive. It intentionally excludes `.env`, live secrets, raw tokens, cookies, database passwords, and Stripe secret keys.",
    "",
    "## Included Files",
    "",
    "- `production-launch-package.md`: launch handoff checklist.",
    "- `deployment-guide.md`: beginner-friendly production setup recipe.",
    "- `render-deployment-guide.md`: Render Blueprint setup recipe.",
    "- `deployment-cutover-checklist.md`: short first-deploy to paid-launch cutover sequence.",
    "- `domain-and-sharing-guide.md`: production URL, sitemap, and shared-link setup recipe.",
    "- `github-and-source-backup-guide.md`: GitHub push, portable backup, Drive, and NotebookLM source trail.",
    "- `home-pc-runbook.md`: beginner-friendly fallback for admin-blocked work computers.",
    "- `home-pc-command-cheatsheet.md`: short command list for finishing checks on a home PC.",
    "- `first-customers-sales-packet.md`: first-buyer outreach scripts and feedback tracker.",
    "- `individual-learner-decision-one-pager.md`: short learner-facing fit and purchase decision handout.",
    "- `practice-manager-approval-one-pager.md`: short practice approval memo for managers and budget decision-makers.",
    "- `first-buyer-fulfillment-checklist.md`: first paid buyer receipt, access, and welcome checklist.",
    "- `revenue-and-sales-tracker-template.md`: safe lead, purchase, support, and weekly revenue tracker.",
    "- `stripe-setup-guide.md`: Stripe checkout and webhook setup recipe.",
    "- `email-setup-guide.md`: passwordless sign-in email setup recipe.",
    "- `database-setup-guide.md`: managed PostgreSQL setup recipe.",
    "- `clinical-review-guide.md`: Module 1 review and signoff recipe.",
    "- `go-live-checklist.md`: final launch-day sequence.",
    "- `production-env-checklist.md`: safe fill-in checklist for host dashboard settings.",
    "- `launch-doctor-report.md`: human-readable paid launch preflight report.",
    "- `manual-launch-qa-evidence.md`: safe template for Stripe, learner-flow, practice-pack, browser, and accessibility QA notes.",
    "- `runtime-readiness-snapshot-guide.md`: how to save and interpret the deployed readiness endpoint.",
    "- `first-sale-support-runbook.md`: safe support checklist for buyer, learner, practice-seat, and refund issues.",
    "- `bootcamp-content-migration-checklist.md`: source-to-course checklist for Drive and NotebookLM Bootcamp assets.",
    "- `module-1-clinical-review-packet.md`: clinical reviewer packet.",
    "- `runtime-readiness-snapshot.json`: safe readiness report with missing variable names, not secret values.",
    "",
    "## Current Snapshot",
    "",
    `- Ready for paid launch: ${readinessReport.readyForPaidLaunch ? "yes" : "no"}`,
    `- Individual learner sales: ${readinessReport.salesChannels.individualLearner.ready ? "ready" : "blocked"}`,
    `- Practice pack sales: ${readinessReport.salesChannels.practicePacks.ready ? "ready" : "blocked"}`,
    `- Runtime warnings: ${readinessReport.warnings.length}`,
    `- Launch blockers: ${readinessReport.staticSummary.blockers.join(", ") || "none"}`,
    "",
    "## Still Needed Before Paid Enrollment",
    "",
    ...readinessReport.launchActions.map(
      action => `- ${action.title}: ${action.action}`
    ),
    "",
  ].join("\n");
}

export async function createLaunchEvidenceBundle({
  outputDir,
  projectRoot = process.cwd(),
  generatedAt = new Date().toISOString(),
  readinessReport = getRuntimeLaunchReadinessReport({ now: () => generatedAt }),
}: LaunchEvidenceBundleInput): Promise<LaunchEvidenceBundleResult> {
  const resolvedOutputDir = path.resolve(projectRoot, outputDir);
  const launchPackagePath = path.resolve(
    projectRoot,
    "docs/launch/production-launch-package.md"
  );
  const files = [
    "README.md",
    "production-launch-package.md",
    "deployment-guide.md",
    "render-deployment-guide.md",
    "deployment-cutover-checklist.md",
    "domain-and-sharing-guide.md",
    "github-and-source-backup-guide.md",
    "home-pc-runbook.md",
    "home-pc-command-cheatsheet.md",
    "first-customers-sales-packet.md",
    "individual-learner-decision-one-pager.md",
    "practice-manager-approval-one-pager.md",
    "first-buyer-fulfillment-checklist.md",
    "revenue-and-sales-tracker-template.md",
    "stripe-setup-guide.md",
    "email-setup-guide.md",
    "database-setup-guide.md",
    "clinical-review-guide.md",
    "go-live-checklist.md",
    "production-env-checklist.md",
    "launch-doctor-report.md",
    "manual-launch-qa-evidence.md",
    "runtime-readiness-snapshot-guide.md",
    "first-sale-support-runbook.md",
    "bootcamp-content-migration-checklist.md",
    "module-1-clinical-review-packet.md",
    "runtime-readiness-snapshot.json",
  ];

  await rm(resolvedOutputDir, { force: true, recursive: true });
  await mkdir(resolvedOutputDir, { recursive: true });

  const launchPackage = await readFile(launchPackagePath, "utf8");
  const deploymentGuide = await readFile(
    path.resolve(projectRoot, "docs/launch/deployment-guide.md"),
    "utf8"
  );
  const renderDeploymentGuide = await readFile(
    path.resolve(projectRoot, "docs/launch/render-deployment-guide.md"),
    "utf8"
  );
  const deploymentCutoverChecklist = await readFile(
    path.resolve(projectRoot, "docs/launch/deployment-cutover-checklist.md"),
    "utf8"
  );
  const domainAndSharingGuide = await readFile(
    path.resolve(projectRoot, "docs/launch/domain-and-sharing-guide.md"),
    "utf8"
  );
  const githubAndSourceBackupGuide = await readFile(
    path.resolve(projectRoot, "docs/launch/github-and-source-backup-guide.md"),
    "utf8"
  );
  const homePcRunbook = await readFile(
    path.resolve(projectRoot, "docs/launch/home-pc-runbook.md"),
    "utf8"
  );
  const homePcCommandCheatsheet = await readFile(
    path.resolve(projectRoot, "docs/launch/home-pc-command-cheatsheet.md"),
    "utf8"
  );
  const firstCustomersSalesPacket = await readFile(
    path.resolve(projectRoot, "docs/launch/first-customers-sales-packet.md"),
    "utf8"
  );
  const individualLearnerDecisionOnePager = await readFile(
    path.resolve(
      projectRoot,
      "docs/launch/individual-learner-decision-one-pager.md"
    ),
    "utf8"
  );
  const practiceManagerApprovalOnePager = await readFile(
    path.resolve(
      projectRoot,
      "docs/launch/practice-manager-approval-one-pager.md"
    ),
    "utf8"
  );
  const firstBuyerFulfillmentChecklist = await readFile(
    path.resolve(
      projectRoot,
      "docs/launch/first-buyer-fulfillment-checklist.md"
    ),
    "utf8"
  );
  const revenueAndSalesTrackerTemplate = await readFile(
    path.resolve(
      projectRoot,
      "docs/launch/revenue-and-sales-tracker-template.md"
    ),
    "utf8"
  );
  const stripeSetupGuide = await readFile(
    path.resolve(projectRoot, "docs/launch/stripe-setup-guide.md"),
    "utf8"
  );
  const emailSetupGuide = await readFile(
    path.resolve(projectRoot, "docs/launch/email-setup-guide.md"),
    "utf8"
  );
  const databaseSetupGuide = await readFile(
    path.resolve(projectRoot, "docs/launch/database-setup-guide.md"),
    "utf8"
  );
  const clinicalReviewGuide = await readFile(
    path.resolve(projectRoot, "docs/launch/clinical-review-guide.md"),
    "utf8"
  );
  const goLiveChecklist = await readFile(
    path.resolve(projectRoot, "docs/launch/go-live-checklist.md"),
    "utf8"
  );
  const productionEnvChecklist = await readFile(
    path.resolve(projectRoot, "docs/launch/production-env-checklist.md"),
    "utf8"
  );
  const manualQaEvidence = await readFile(
    path.resolve(projectRoot, "docs/launch/manual-launch-qa-evidence.md"),
    "utf8"
  );
  const runtimeReadinessSnapshotGuide = await readFile(
    path.resolve(
      projectRoot,
      "docs/launch/runtime-readiness-snapshot-guide.md"
    ),
    "utf8"
  );
  const firstSaleSupportRunbook = await readFile(
    path.resolve(projectRoot, "docs/launch/first-sale-support-runbook.md"),
    "utf8"
  );
  const bootcampContentMigrationChecklist = await readFile(
    path.resolve(
      projectRoot,
      "docs/launch/bootcamp-content-migration-checklist.md"
    ),
    "utf8"
  );
  const moduleOneClinicalReviewPacket = await readFile(
    path.resolve(projectRoot, "docs/launch/module-1-clinical-review-packet.md"),
    "utf8"
  );

  await writeFile(
    path.join(resolvedOutputDir, "README.md"),
    renderReadme({ generatedAt, readinessReport })
  );
  await writeFile(
    path.join(resolvedOutputDir, "production-launch-package.md"),
    launchPackage
  );
  await writeFile(
    path.join(resolvedOutputDir, "deployment-guide.md"),
    deploymentGuide
  );
  await writeFile(
    path.join(resolvedOutputDir, "render-deployment-guide.md"),
    renderDeploymentGuide
  );
  await writeFile(
    path.join(resolvedOutputDir, "deployment-cutover-checklist.md"),
    deploymentCutoverChecklist
  );
  await writeFile(
    path.join(resolvedOutputDir, "domain-and-sharing-guide.md"),
    domainAndSharingGuide
  );
  await writeFile(
    path.join(resolvedOutputDir, "github-and-source-backup-guide.md"),
    githubAndSourceBackupGuide
  );
  await writeFile(
    path.join(resolvedOutputDir, "home-pc-runbook.md"),
    homePcRunbook
  );
  await writeFile(
    path.join(resolvedOutputDir, "home-pc-command-cheatsheet.md"),
    homePcCommandCheatsheet
  );
  await writeFile(
    path.join(resolvedOutputDir, "first-customers-sales-packet.md"),
    firstCustomersSalesPacket
  );
  await writeFile(
    path.join(resolvedOutputDir, "individual-learner-decision-one-pager.md"),
    individualLearnerDecisionOnePager
  );
  await writeFile(
    path.join(resolvedOutputDir, "practice-manager-approval-one-pager.md"),
    practiceManagerApprovalOnePager
  );
  await writeFile(
    path.join(resolvedOutputDir, "first-buyer-fulfillment-checklist.md"),
    firstBuyerFulfillmentChecklist
  );
  await writeFile(
    path.join(resolvedOutputDir, "revenue-and-sales-tracker-template.md"),
    revenueAndSalesTrackerTemplate
  );
  await writeFile(
    path.join(resolvedOutputDir, "stripe-setup-guide.md"),
    stripeSetupGuide
  );
  await writeFile(
    path.join(resolvedOutputDir, "email-setup-guide.md"),
    emailSetupGuide
  );
  await writeFile(
    path.join(resolvedOutputDir, "database-setup-guide.md"),
    databaseSetupGuide
  );
  await writeFile(
    path.join(resolvedOutputDir, "clinical-review-guide.md"),
    clinicalReviewGuide
  );
  await writeFile(
    path.join(resolvedOutputDir, "go-live-checklist.md"),
    goLiveChecklist
  );
  await writeFile(
    path.join(resolvedOutputDir, "production-env-checklist.md"),
    productionEnvChecklist
  );
  await writeFile(
    path.join(resolvedOutputDir, "launch-doctor-report.md"),
    renderLaunchDoctorReport({ readinessReport })
  );
  await writeFile(
    path.join(resolvedOutputDir, "manual-launch-qa-evidence.md"),
    manualQaEvidence
  );
  await writeFile(
    path.join(resolvedOutputDir, "runtime-readiness-snapshot-guide.md"),
    runtimeReadinessSnapshotGuide
  );
  await writeFile(
    path.join(resolvedOutputDir, "first-sale-support-runbook.md"),
    firstSaleSupportRunbook
  );
  await writeFile(
    path.join(resolvedOutputDir, "bootcamp-content-migration-checklist.md"),
    bootcampContentMigrationChecklist
  );
  await writeFile(
    path.join(resolvedOutputDir, "module-1-clinical-review-packet.md"),
    moduleOneClinicalReviewPacket
  );
  await writeFile(
    path.join(resolvedOutputDir, "runtime-readiness-snapshot.json"),
    `${JSON.stringify(readinessReport, null, 2)}\n`
  );

  return {
    outputDir: resolvedOutputDir,
    files,
  };
}
