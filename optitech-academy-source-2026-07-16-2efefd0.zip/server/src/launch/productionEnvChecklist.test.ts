import { describe, expect, it } from "vitest";
import { renderProductionEnvChecklist } from "./productionEnvChecklist";

describe("renderProductionEnvChecklist", () => {
  it("renders a safe fill-in checklist for production variables", () => {
    const checklist = renderProductionEnvChecklist({
      generatedAt: "2026-07-13T12:00:00.000Z",
    });

    expect(checklist).toContain(
      "OptiTech Academy Production Environment Checklist"
    );
    expect(checklist).toContain("`STRIPE_SECRET_KEY`");
    expect(checklist).toContain("`DATABASE_URL`");
    expect(checklist).toContain("`ENABLE_PAID_ENROLLMENT`");
    expect(checklist).toContain("`ALERT_ADMIN_TOKEN`");
    expect(checklist).toContain("`VITE_ANALYTICS_ENDPOINT`");
    expect(checklist).toContain("`LAUNCH_SITEMAP_PATH`");
    expect(checklist).toContain("Resend keys should start with re_");
    expect(checklist).toContain("Host Dashboard Paste Template");
    expect(checklist).toContain("ENABLE_PAID_ENROLLMENT=false");
    expect(checklist).toContain("MODULE_ONE_CLINICAL_REVIEW_APPROVED=false");
    expect(checklist).toContain("Never paste this template into GitHub");
    expect(checklist).toContain("pnpm launch:doctor");
    expect(checklist).not.toContain("sk_test_");
    expect(checklist).not.toContain("replace_with");
  });
});
